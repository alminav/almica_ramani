/*
 *  Licensed to GraphHopper and Peter Karich under one or more contributor
 *  license agreements. See the NOTICE file distributed with this work for 
 *  additional information regarding copyright ownership.
 *
 *  GraphHopper licenses this file to you under the Apache License, 
 *  Version 2.0 (the "License"); you may not use this file except in 
 *  compliance with the License. You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package com.graphhopper.routing.util;

import com.graphhopper.util.EdgeIteratorState;

/**
 * Class used to traverse a graph.
 * <p/>
 * @author Peter Karich
 */
public interface EdgeFilter
{
    /**
     * @return true if the current edge should be processed and false otherwise.
     */
    boolean accept( EdgeIteratorState edgeIterState );

    static final EdgeFilter ALL_EDGES = new EdgeFilter()
    {
        @Override
        public final boolean accept( EdgeIteratorState edgeIterState )
        {
            return true;
        }
    };
}
